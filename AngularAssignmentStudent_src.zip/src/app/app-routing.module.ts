import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { StudloginformsComponent } from './studloginforms/studloginforms.component';
import { StudMarklistformsComponent } from './stud-marklistforms/stud-marklistforms.component';

const routes: Routes = [
  {path:"studloginforms",component:StudloginformsComponent},
  {path:"studMarklistforms",component:StudMarklistformsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
