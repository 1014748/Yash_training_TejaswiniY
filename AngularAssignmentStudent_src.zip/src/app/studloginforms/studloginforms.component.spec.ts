import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudloginformsComponent } from './studloginforms.component';

describe('StudloginformsComponent', () => {
  let component: StudloginformsComponent;
  let fixture: ComponentFixture<StudloginformsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StudloginformsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StudloginformsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
