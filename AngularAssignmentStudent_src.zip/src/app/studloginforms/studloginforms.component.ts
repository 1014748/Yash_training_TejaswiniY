import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-studloginforms',
  templateUrl: './studloginforms.component.html',
  styleUrls: ['./studloginforms.component.css']
})
export class StudloginformsComponent implements OnInit {

  contactform:FormGroup;
  formData:any={};
  overallresult:any=true;
  result:any=0;

totalmarks:number=0;
totalmarkshow:any=0;

percentage:number=0;
percentageshow:any=0;

grade:any=0;
overallgrade:any=0;

message:boolean=false;

  constructor() { 
    this.contactform=new FormGroup({
      fname:new FormControl("",[Validators.required,Validators.minLength(2)]),
      class:new FormControl("",[Validators.required,Validators.minLength(2)]),
      rollNo:new FormControl("",[Validators.required,Validators.minLength(1)]),
      maths:new FormControl("",[Validators.required,Validators.minLength(2)]),
      physics:new FormControl("",[Validators.required,Validators.minLength(2)]),
      chemistry:new FormControl("",[Validators.required,Validators.minLength(2)]),
      biology:new FormControl("",[Validators.required,Validators.minLength(2)])

    });

  }

    check()
    {
      if(this.percentage < 40)
      {
        console.log("Fail");
        this.overallresult=false;
        this.grade="Fail";

      }
      else if(this.percentage<50)
      {
        console.log("C Grade");
        this.grade="C Grade";

      }
      else if(this.percentage<60)
      {
        console.log("C+ Grade");
        this.grade="C+ Grade";

      }
      else if(this.percentage<70)
      {
        console.log("B Grade");
        this.grade="B Grade";

      }
      else if(this.percentage<80)
      {
        console.log("B+ Grade");
        this.grade="B+ Grade";

      }
      else
      {
        console.log("A Grade");
        this.grade="A Grade";
      }
      this.overallgrade="Grade "+this.grade;
    }

  ngOnInit(): void {
  }
  onSubmit():void{
    console.log(this.contactform.value);

  this.result=this.contactform.value;
  
  this.totalmarks=parseInt(this.result.maths)+parseInt(this.result.physics)+parseInt(this.result.chemistry)+parseInt(this.result.biology);
  this.totalmarkshow="Total Percentage "+(this.totalmarks);
  console.log("Total Marks "+typeof(this.totalmarks));
  console.log("Total Marks "+this.totalmarkshow);


  this.percentage=this.totalmarks/4;
  this.percentageshow="Total Percentage "+this.percentage;
  console.log("Total Percentage "+this.percentage);

  this.check();
  if(this.overallresult==true)
  {
    this.overallresult="Result= Passed";
    this.message=true;
  }
  else{
    this.overallresult="Result = Failed"
  }
  
}
removeMsg(){
  this.message=false;
}
}