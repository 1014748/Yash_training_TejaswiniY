import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stud-marklistforms',
  templateUrl: './stud-marklistforms.component.html',
  styleUrls: ['./stud-marklistforms.component.css']
})
export class StudMarklistformsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
