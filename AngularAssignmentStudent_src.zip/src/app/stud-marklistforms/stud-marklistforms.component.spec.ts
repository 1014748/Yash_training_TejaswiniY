import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudMarklistformsComponent } from './stud-marklistforms.component';

describe('StudMarklistformsComponent', () => {
  let component: StudMarklistformsComponent;
  let fixture: ComponentFixture<StudMarklistformsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StudMarklistformsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StudMarklistformsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
