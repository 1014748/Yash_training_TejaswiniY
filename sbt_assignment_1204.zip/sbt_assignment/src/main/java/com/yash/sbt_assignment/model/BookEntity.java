package com.yash.sbt_assignment.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class BookEntity {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	 int bid,aid1,aid2,aid3;
	String btitle,pubid,price;
	public int getBid() {
		return bid;
	}
	public BookEntity() {
		
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public int getAid1() {
		return aid1;
	}
	public void setAid1(int aid1) {
		this.aid1 = aid1;
	}
	public int getAid2() {
		return aid2;
	}
	public void setAid2(int aid2) {
		this.aid2 = aid2;
	}
	public int getAid3() {
		return aid3;
	}
	public void setAid3(int aid3) {
		this.aid3 = aid3;
	}
	public String getBtitle() {
		return btitle;
	}
	public void setBtitle(String btitle) {
		this.btitle = btitle;
	}
	public String getPubid() {
		return pubid;
	}
	public void setPubid(String pubid) {
		this.pubid = pubid;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
}
