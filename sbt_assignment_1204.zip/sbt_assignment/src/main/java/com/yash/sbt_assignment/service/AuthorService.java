package com.yash.sbt_assignment.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.yash.sbt_assignment.model.AuthorEntity;
import com.yash.sbt_assignment.model.BookEntity;
import com.yash.sbt_assignment.repository.AuthorRepo;


@Component
public class AuthorService {
	@Autowired
	AuthorRepo srpo;
	
	
	   public int saveAuthorService(AuthorEntity objse) 
	   {
		   objse =srpo.save(objse);
		   return objse.getAid(); 
	   } 
	   public Iterable<AuthorEntity> getAllAuthorsList() 
	   {   
		   return srpo.findAll() ; 
	   } 
	   public List<AuthorEntity> getAllAuthorList() {
		   	List<AuthorEntity> slist= new ArrayList<>();
	   		srpo.findAll().forEach(slist::add); return slist; 
	   } 
	   public Optional<AuthorEntity> getAuthorById(Integer aid) 
	   { 
		   	return srpo.findById(aid); 
	   } 
	   public void delAuthorById(Integer aid) 
	   {
		   	srpo.deleteById(aid);
	   } 
	   public void updateAuthorById(AuthorEntity seobj) 
	   { 
		   	srpo.save(seobj);//for new record it will insert and for already existing record it will update
	   }
	   //saveOrUpdate(); }
	/*   public int saveBookService(BookEntity objse) 
	   {
		   objse =srpo.save(objse);
		   return objse.getBid(); 
	   } 
	   public Iterable<BookEntity> getAllBooksList() 
	   {   
		   return srpo.findAll() ; 
	   } 
	   public List<BookEntity> getAllBookList() {
		   	List<BookEntity> slist= new ArrayList<>();
		   	srpo.findAll().forEach(slist::add); return slist; 
	   } 
	   public Optional<BookEntity> getBookById(Integer aid) 
	   { 
		   	return srpo.findById(aid); 
	   } 
	   public void delBookById(Integer aid) 
	   {
		   srpo.deleteById(aid);
	   } 
	   public void updateBookById(BookEntity seobj) 
	   { 
		   srpo.save(seobj);//for new record it will insert and for already existing record it will update
	   }*/
	   //saveOrUpdate(); }
}
