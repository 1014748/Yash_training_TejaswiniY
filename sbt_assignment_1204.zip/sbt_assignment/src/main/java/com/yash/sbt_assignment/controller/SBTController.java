package com.yash.sbt_assignment.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.yash.sbt_assignment.model.AuthorEntity;
import com.yash.sbt_assignment.model.BookEntity;
import com.yash.sbt_assignment.model.PublisherEntity;
import com.yash.sbt_assignment.service.AuthorService;
import com.yash.sbt_assignment.service.BookService;
import com.yash.sbt_assignment.service.PublisherService;

@Controller
public class SBTController {
	
	AuthorService auobj;
	BookService bookobj;
	PublisherService pobj;
	@RequestMapping("/")
	public String index()
	{		
		return "index";
	}
	@RequestMapping("/saveAuthor")
	public ModelAndView saveAuthor(@ModelAttribute AuthorEntity seobj)
	{
		ModelAndView mv = new ModelAndView();
		//if(auobj.saveAuthorService(seobj)>0)
		//{
			mv.addObject("seobj", seobj);
			mv.setViewName("authorDetails");
			return mv;
		//}
		//else
		//{
			//mv.setViewName("index");
			//return mv;
		//}		
	}
	@RequestMapping("/listAuthor")
	public ModelAndView listallauthor()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("authorlist");
		List<AuthorEntity> slist=auobj.getAllAuthorList();
		mv.addObject("slist", slist);
		return mv;
	}
	@RequestMapping("/editauthor/{aid}")
	public ModelAndView editAuthorget(@PathVariable("aid") String aid)
	{
		ModelAndView mv = new ModelAndView();
		Optional<AuthorEntity> seobj=	auobj.getAuthorById(Integer.parseInt(aid));
		if(seobj.isPresent())
		{
			AuthorEntity sobj = seobj.get();
			mv.addObject("sobj", sobj);
			mv.setViewName("editauthor_view");
			return mv;
			
		}
		else
			{ return new ModelAndView("redirect:/listAuthor");
			}
	}
	@RequestMapping("/editAuthorSubmit")
	public ModelAndView editSS(@ModelAttribute AuthorEntity seobj)
	{
		ModelAndView mv = new ModelAndView();
		 
		
		auobj.updateAuthorById(seobj);
		
		mv.setViewName("redirect:/listAuthor");
		return mv;
		
	}
	@RequestMapping("/delAuthor/{aid}")
	public ModelAndView delAuthor(@PathVariable("aid") String aid)
	{
		ModelAndView mv = new ModelAndView();
		auobj.delAuthorById(Integer.parseInt(aid));
		mv.setViewName("redirect:/listAuthor");
		return mv;
	}
	@RequestMapping("/saveBook")
	public ModelAndView saveBook(@ModelAttribute BookEntity bobj)
	{
		ModelAndView mv = new ModelAndView();
			mv.addObject("bobj", bobj);
			mv.setViewName("bookDetails");
			return mv;		
	}
	@RequestMapping("/listBook")
	public ModelAndView listallbook()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("booklist");
		List<BookEntity> slist=bookobj.getAllBookList();
		mv.addObject("slist", slist);
		return mv;
	}
	@RequestMapping("/editBook/{bid}")
	public ModelAndView editBookget(@PathVariable("bid") String bid)
	{
		ModelAndView mv = new ModelAndView();
		Optional<BookEntity> seobj=	bookobj.getBookById(Integer.parseInt(bid));
		if(seobj.isPresent())
		{
			BookEntity sobj = seobj.get();
			mv.addObject("sobj", sobj);
			mv.setViewName("editbook_view");
			return mv;
			
		}
		else
			{ return new ModelAndView("redirect:/listBook");
			}
	}
	@RequestMapping("/editBookSubmit")
	public ModelAndView editBooks(@ModelAttribute BookEntity seobj)
	{
		ModelAndView mv = new ModelAndView();
		 
		
		bookobj.updateBookById(seobj);
		
		mv.setViewName("redirect:/listBook");
		return mv;
		
	}
	@RequestMapping("/delBook/{bid}")
	public ModelAndView delBook(@PathVariable("bid") String bid)
	{
		ModelAndView mv = new ModelAndView();
		bookobj.delBookById(Integer.parseInt(bid));
		mv.setViewName("redirect:/listBook");
		return mv;
	}
	@RequestMapping("/savePub")
	public ModelAndView savePub(@ModelAttribute PublisherEntity bobj)
	{
		ModelAndView mv = new ModelAndView();
			mv.addObject("pobj", bobj);
			mv.setViewName("pubDetails");
			return mv;		
	}
	@RequestMapping("/listPub")
	public ModelAndView listallpub()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("publist");
		List<PublisherEntity> slist=pobj.getAllPublisherList();
		mv.addObject("slist", slist);
		return mv;
	}
	@RequestMapping("/editpub/{pubid}")
	public ModelAndView editPubget(@PathVariable("pubid") String pubid)
	{
		ModelAndView mv = new ModelAndView();
		Optional<PublisherEntity> seobj=	pobj.getPublisherById(Integer.parseInt(pubid));
		if(seobj.isPresent())
		{
			PublisherEntity sobj = seobj.get();
			mv.addObject("sobj", sobj);
			mv.setViewName("editPub_view");
			return mv;
			
		}
		else
			{ return new ModelAndView("redirect:/listPub");
			}
	}
	@RequestMapping("/editPubSubmit")
	public ModelAndView editpubs(@ModelAttribute PublisherEntity seobj)
	{
		ModelAndView mv = new ModelAndView();
		 
		
		pobj.updatePublisherById(seobj);
		
		mv.setViewName("redirect:/listPub");
		return mv;
		
	}
	@RequestMapping("/delpub/{pubid}")
	public ModelAndView delPub(@PathVariable("pubid") String pubid)
	{
		ModelAndView mv = new ModelAndView();
		pobj.delPublisherById(Integer.parseInt(pubid));
		mv.setViewName("redirect:/listPub");
		return mv;
	}
  
}
