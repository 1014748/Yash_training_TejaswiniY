package com.yash.sbt_assignment.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.yash.sbt_assignment.model.BookEntity;
import com.yash.sbt_assignment.repository.BookRepo;
@Component
public class BookService {
@Autowired
BookRepo brpo;
	   public int saveBookService(BookEntity objse) 
	   {
		   objse =brpo.save(objse);
		   return objse.getBid(); 
	   } 
	   public Iterable<BookEntity> getAllBooksList() 
	   {   
		   return brpo.findAll() ; 
	   } 
	   public List<BookEntity> getAllBookList() {
		   	List<BookEntity> slist= new ArrayList<>();
		   	brpo.findAll().forEach(slist::add); return slist; 
	   } 
	   public Optional<BookEntity> getBookById(Integer aid) 
	   { 
		   	return brpo.findById(aid); 
	   } 
	   public void delBookById(Integer aid) 
	   {
		   brpo.deleteById(aid);
	   } 
	   public void updateBookById(BookEntity seobj) 
	   { 
		   brpo.save(seobj);//for new record it will insert and for already existing record it will update
	   }
	   //saveOrUpdate(); }

}
