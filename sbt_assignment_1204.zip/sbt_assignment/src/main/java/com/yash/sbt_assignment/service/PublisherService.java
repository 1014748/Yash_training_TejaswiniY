package com.yash.sbt_assignment.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.yash.sbt_assignment.model.PublisherEntity;
import com.yash.sbt_assignment.repository.PublisherRepo;
@Component
public class PublisherService {

	@Autowired
	PublisherRepo prpo;
		   public int savePublisherService(PublisherEntity objse) 
		   {
			   objse =prpo.save(objse);
			   return objse.getPubid(); 
		   } 
		   public Iterable<PublisherEntity> getAllPublishersList() 
		   {   
			   return prpo.findAll() ; 
		   } 
		   public List<PublisherEntity> getAllPublisherList() {
			   	List<PublisherEntity> slist= new ArrayList<>();
			   	prpo.findAll().forEach(slist::add); return slist; 
		   } 
		   public Optional<PublisherEntity> getPublisherById(Integer aid) 
		   { 
			   	return prpo.findById(aid); 
		   } 
		   public void delPublisherById(Integer aid) 
		   {
			   prpo.deleteById(aid);
		   } 
		   public void updatePublisherById(PublisherEntity seobj) 
		   { 
			   prpo.save(seobj);//for new record it will insert and for already existing record it will update
		   }
}
