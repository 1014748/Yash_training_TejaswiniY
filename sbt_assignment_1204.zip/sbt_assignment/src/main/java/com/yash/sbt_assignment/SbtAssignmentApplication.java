package com.yash.sbt_assignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbtAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbtAssignmentApplication.class, args);
	}

}
