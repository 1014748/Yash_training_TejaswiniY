package com.yash.sbt_assignment.repository;

import org.springframework.data.repository.CrudRepository;

import com.yash.sbt_assignment.model.AuthorEntity;

public interface AuthorRepo extends CrudRepository<AuthorEntity, Integer> {

}
