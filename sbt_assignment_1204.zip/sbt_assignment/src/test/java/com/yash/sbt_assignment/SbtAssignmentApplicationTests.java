package com.yash.sbt_assignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbtAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
