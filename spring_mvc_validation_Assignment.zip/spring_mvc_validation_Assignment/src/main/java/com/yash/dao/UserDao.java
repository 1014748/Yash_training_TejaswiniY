package com.yash.dao;  
import java.sql.ResultSet;  
import java.sql.SQLException;  
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;  
import org.springframework.jdbc.core.JdbcTemplate;  
import org.springframework.jdbc.core.RowMapper;

import com.yash.controller.User;

  
public class UserDao {  
	@Autowired	
	JdbcTemplate objJdbc;
	public void setObjJdbc(JdbcTemplate objJdbc) {
	}
public int save(User obju){  
	String sql="insert into user (name,pass,email,address,mobileno) values(?,?,?,?,?)";
	 return objJdbc.update(sql, obju.getName(),obju.getPass(),obju.getEmail(),obju.getAddress(),Long.parseLong(obju.getMobileno()) );

}  
public int update(User p){  
    String sql="update user set name='"+p.getName()+"', email='"+p.getEmail()+"',address='"+p.getAddress()+"',mobileno="+Long.parseLong(p.getMobileno())+" where uid="+p.getUid()+"";    
    return objJdbc.update(sql);  
}  
public int delete(int id){  
    String sql="delete from user where uid="+id+"";  
    return objJdbc.update(sql);  
}  
public User getUserById(int id){  
    String sql="select * from user where uid=?";  
    return objJdbc.queryForObject(sql, new Object[]{id},new BeanPropertyRowMapper<User>(User.class));  
}  
public List<User> getAllUser(){  
    return objJdbc.query("select * from user",new RowMapper<User>(){  
        public User mapRow(ResultSet rs, int row) throws SQLException {  
            User obju=new User();  
            obju.setUid(rs.getInt("uid"));
			  obju.setName(rs.getString("name"));
			  obju.setEmail(rs.getString("email"));
			  obju.setMobileno(""+rs.getLong("mobileno"));
			  return obju;
        }  
    });  
}  
}  