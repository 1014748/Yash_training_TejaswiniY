package com.yash.controller;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.*;
import org.springframework.lang.NonNull;
public class Store {
		
 int aid;
 int itemId;
 int custid;
 
 public int getCustid() {
	return custid;
}
public void setCustid(int custid) {
	this.custid = custid;
}
public int getItemId() {
	return itemId;
}
public void setItemId(int itemId) {
	this.itemId = itemId;
}
// java script or jquery or angular way /^[a-zA-Z0-9]{2,15}$/
 @NonNull
 @Pattern(regexp="^[a-zA-Z0-9 ]{2,15}$",message="name can only contain alphabets and digits and minimum length")
 String name;
 
 /* @Size(min=2,message="name can not be less than 2 char in length")*/
 @Size(min=7, max = 14, message="password should be between 7 to 14 in length")
 String pass;
 @Size(min=7, max = 14, message="password should be between 7 to 14 in length")
 String passCust;
 public String getPassCust() {
	return passCust;
}
public void setPassCust(String passCust) {
	this.passCust = passCust;
}
@NotEmpty
 @Email(message = "please enter valid email")
 String emailid;

 @Pattern(regexp="^[6-9][0-9]{9}$",message="please start no with 6 ,7, 8 or 9 exact digit 10")
 String mobileno;
 
	/*
	 * @NotEmpty(message="please select gender") String gender;
	 * 
	 * public String getGender() { return gender; } public void setGender(String
	 * gender) { this.gender = gender; }
	 */
 @Pattern(regexp="^[a-zA-Z0-9 ]{2,30}$",message="Item can only contain alphabets and digits and minimum length")
 String itemName;
 String itemExpiryDate;
 String itemManuDate;
 @Pattern(regexp="^[a-zA-Z0-9 ]{2,15}$",message="name can only contain alphabets and digits and minimum length")
 String custname;
 String address;
 
 int categoryid;
 
 String itemPrice;
 String Category;
 
public String getCategory() {
	return Category;
}
public void setCategory(String category) {
	Category = category;
}
public Store()
 {	 
 }
public int getCategoryid() {
	return categoryid;
}
public void setCategoryid(int categoryid) {
	this.categoryid = categoryid;
}
public int getAid() {
	return aid;
}
public void setAid(int aid) {
	this.aid = aid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmailid() {
	return emailid;
}
public void setEmailid(String emailid) {
	this.emailid = emailid;
}
public String getItemName() {
	return itemName;
}
public void setItemName(String itemName) {
	this.itemName = itemName;
}
public String getItemExpiryDate() {
	return itemExpiryDate;
}
public void setItemExpiryDate(String itemExpiryDate) {
	this.itemExpiryDate = itemExpiryDate;
}
public String getItemManuDate() {
	return itemManuDate;
}
public void setItemManuDate(String itemManuDate) {
	this.itemManuDate = itemManuDate;
}
public String getCustname() {
	return custname;
}
public void setCustname(String custname) {
	this.custname = custname;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getItemPrice() {
	return itemPrice;
}
public void setItemPrice(String itemPrice) {
	this.itemPrice = itemPrice;
}
public String getPass() {
	return pass;
}
public void setPass(String pass) {
	this.pass = pass;
}
public String getMobileno() {
	return mobileno;
}
public void setMobileno(String mobileno) {
	this.mobileno = mobileno;
}
 
}
