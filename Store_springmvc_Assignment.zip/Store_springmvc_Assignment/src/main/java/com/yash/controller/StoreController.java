package com.yash.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.apache.catalina.realm.X509UsernameRetriever;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import com.yash.dao.*;
@Controller  
public class StoreController {  
    @Autowired  
    StoreDao storedao;//will inject dao from xml file  
      
    @RequestMapping(value="/")
	public String first()
	{
		return "index";
	}
	@GetMapping("/signup")
	public String userReg(Model m)
	{
		Store objuser = new Store();
		m.addAttribute("objstore", objuser);
		return "signup";
	}
	@PostMapping("/SignUpSubmit")
	public String UserRegSubmit(@Valid @ModelAttribute("objstore") Store objuser, BindingResult objBR)
	{
		if(objBR.hasErrors())
		  return "signup";
		else
		{
			if(storedao.save(objuser)==1)
				return "signup_success";
			else
				return "index";
			
		}
	}  
	@GetMapping("/login")
	public String userLogin(Model m)
	{	
		Store objuser = new Store();
		m.addAttribute("objstore", objuser);
		return "adminlogin";
	}
	//@PostMapping(value="/loginSuccess")
    @RequestMapping(value="/loginSuccess",method = RequestMethod.POST)  

	public String UserloginSubmit(@Valid @ModelAttribute("objstore") Store objstore, BindingResult objBR,Model m)
	{
			System.out.println(" Name "+objstore.getName()+"Password "+objstore.getPass());
			if(objstore != null && objstore.getName()!=null && objstore.getPass()!=null)
			{
				if(objstore.getName().equals("TEJAS65") && objstore.getPass().equals("nhagf12345"))
				{
					m.addAttribute(objstore);
					return "loginSuccesss";
				}
				return "adminNotFound";

			}
			else
				return "adminNotFound";
			
	} 
    @RequestMapping("/view")  
    public String view(Model m){  
        List<Store> list=storedao.getAllItem();  
        m.addAttribute("list",list);
        return "view";  
    }
    @RequestMapping("/viewCustomerDeatil")  
    public String viewCustomerDetail(Model m){  
        List<Store> list=storedao.getAllCustomer();  
        m.addAttribute("list",list);
        return "viewCustomerDeatil";  
    }
    @RequestMapping("/viewCategory")  
    public String viewCategory(Model m){  
        List<Store> list=storedao.getAllCategory();  
        m.addAttribute("list",list);
        return "viewCategory";  
    }
    @GetMapping("/AddItem")
	public String AddItem(Model m)
	{
		Store objuser = new Store();
		m.addAttribute("objstore", objuser);
		return "AddItem";
	}
	//@PostMapping("/addDeatil")
    @RequestMapping(value="/addItemDeatil",method = RequestMethod.POST) 
	public String addDetails(@Valid @ModelAttribute("objstore") Store objstore, BindingResult objBR,Model m)
	{
			storedao.saveItem(objstore);
			List<Store> list=storedao.getAllItem();  
	        m.addAttribute("list",list);
				return "view";
			
	} 
    @GetMapping("/AddCustomer")
	public String AddCustomer(Model m)
	{
		Store objuser = new Store();
		m.addAttribute("objstore", objuser);
		return "AddCustomer";
	}
    @RequestMapping(value="/addCustomerDeatil",method = RequestMethod.POST) 
   	public String addCustomerDetails(@Valid @ModelAttribute("objstore") Store objstore, BindingResult objBR,Model m)
   	{
   			storedao.saveCustomer(objstore);
   			List<Store> list=storedao.getAllCustomer();  
   	        m.addAttribute("list",list);
   	        return "viewCustomerDeatil";
   			
   	} 
    @GetMapping("/AddCategory")
	public String AddCategory(Model m)
	{
		Store objuser = new Store();
		m.addAttribute("objstore", objuser);
		return "AddCategory";
	}
    @RequestMapping(value="/addCategoryDeatil",method = RequestMethod.POST) 
   	public String addCategoryDeatil(@Valid @ModelAttribute("objstore") Store objstore, BindingResult objBR,Model m)
   	{
   			storedao.saveCategory(objstore);
   			List<Store> list=storedao.getAllCategory();  
   	        m.addAttribute("list",list);
   	        return "viewCategory";
   			
   	} 
    @RequestMapping(value="/edititem/{itemId}")  
    public String editItem(@PathVariable int itemId, Model m){  
        Store objstore=storedao.getItemById(itemId);  
        m.addAttribute("objstore",objstore);
        return "itemeditform";  
    } 
    @PostMapping(value="/editi")  
    public String editsave(@ModelAttribute("objstore") Store objstore,BindingResult br,Model m){ 
    	
    	storedao.updateitem(objstore);  
    	List<Store> list=storedao.getAllItem();  
        m.addAttribute("list",list);
			return "view"; 
    } 
    @RequestMapping(value="/editCust/{custid}")  
    public String editCust(@PathVariable int custid, Model m){  
        Store objstore=storedao.getCustById(custid);  
        m.addAttribute("objstore",objstore);
        return "custeditform";  
    } 
    @PostMapping(value="/editcust")  
    public String editcust(@ModelAttribute("objstore") Store objstore,BindingResult br,Model m){ 
    	
    	storedao.updatecust(objstore);  
    	List<Store> list=storedao.getAllCustomer();  
        m.addAttribute("list",list);
			return "viewCustomerDeatil"; 
    } 
    @RequestMapping(value="/editCategory/{categoryid}")  
    public String editCategory(@PathVariable int categoryid, Model m){  
    	Store objstore=storedao.getCategoryById(categoryid);  
        m.addAttribute("objstore",objstore);
        return "categoryeditform";  
    } 
    @PostMapping(value="/editcat")  
    public String editcat(@ModelAttribute("objstore") Store objstore,BindingResult br,Model m){ 
    	
    	storedao.updatecategory(objstore);  
    	List<Store> list=storedao.getAllCategory();  
        m.addAttribute("list",list);
			return "viewCategory"; 
    } 
  /*  @RequestMapping(value="/save",method = RequestMethod.POST)  
    public String save(@ModelAttribute("user") Store user){  
    	storedao.save(user);  
        return "viewuser";//will redirect to viewuser request mapping  
    }  
   
    @RequestMapping("/viewuser")  
    public String viewuser(Model m){  
        List<Store> list=storedao.getAllUser();  
        m.addAttribute("list",list);
        return "viewuser";  
    }  

    @RequestMapping(value="/edituser/{uid}")  
    public String edit(@PathVariable int uid, Model m){  
        Store user=storedao.getUserById(uid);  
        m.addAttribute("objuser",user);
        return "usereditform";  
    }  
    @PostMapping(value="/editsave")  
    public String editsave(@ModelAttribute("objstore") Store user,BindingResult br,Model m){ 
    	
    	System.out.println("Name "+user.getName()+" Mobile "+user.getMobileno());
    	storedao.update(user);  
    	List<Store> list=storedao.getAllUser(); 
    	m.addAttribute("list",list);
        return "viewuser";  
    }  

    @RequestMapping(value="/deleteuser/{uid}",method = RequestMethod.GET)  
    public String delete(@PathVariable int uid,Model m){ 
    	System.out.println("ID "+uid);
    	storedao.delete(uid);  
    	List<Store> list=storedao.getAllUser(); 
    	m.addAttribute("list",list);
        return "viewuser";  
    }   */
}  