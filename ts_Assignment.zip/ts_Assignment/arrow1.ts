var test=() =>console.log("List of Marks \n");
test();

var Show =(a:number,b:number,c:number,d:number)=> a,b,c,d;
console.log("Maths \t Physics \t Chemistry \t Biology \n");
console.log(Show(23,34,65,76));