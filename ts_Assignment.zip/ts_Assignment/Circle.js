var Circle = /** @class */ (function () {
    function Circle(circumference) {
        this.circumference = circumference;
    }
    Circle.prototype.show = function () {
        console.log("Circumference:-  " + this.circumference);
    };
    Circle.prototype.radiusCircle = function () {
        this.show();
        this.radius = this.circumference / (2 * 3.14);
        console.log("Radius of Circle " + this.radius);
    };
    return Circle;
}());
var obj = new Circle(10);
obj.radiusCircle();
