var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Shape = /** @class */ (function () {
    function Shape(name) {
        this.name = name;
    }
    Shape.prototype.showShape = function () {
        console.log("Name of Shape " + this.name);
    };
    return Shape;
}());
var Rectangle = /** @class */ (function (_super) {
    __extends(Rectangle, _super);
    function Rectangle(l, w) {
        var _this = _super.call(this, "Rectangle") || this;
        _this.l = l;
        _this.w = w;
        return _this;
    }
    Rectangle.prototype.areaRec = function () {
        this.showShape();
        this.areaa = this.l * this.w;
        console.log("Area of Rectangle " + this.areaa);
    };
    return Rectangle;
}(Shape));
var objRect = new Rectangle(7, 9);
objRect.areaRec();
var Square = /** @class */ (function (_super) {
    __extends(Square, _super);
    function Square(a) {
        var _this = _super.call(this, "Square") || this;
        _this.a = a;
        return _this;
    }
    Square.prototype.areaSquare = function () {
        this.showShape();
        this.areaa = this.a * this.a;
        console.log("Area of Square " + this.areaa);
    };
    return Square;
}(Shape));
var objSqr = new Square(4);
objSqr.areaSquare();
