var test = function () { return console.log("List of Marks \n"); };
test();
var Show = function (a, b) { return a; }, b;
console.log("Maths \t Physics \t Chemistry \t Biology \n");
console.log(Show(23, 34));
