
class Shape
{
		areaa:number;
		name:string;
		constructor(name:string)
		{
			this.name=name;
		}
		showShape()
		{
			console.log("Name of Shape "+this.name);
		}
}

class Rectangle extends Shape
{
	l:number;
	w:number;
	
	constructor(l:number,w:number)
	{
		super("Rectangle");
		this.l=l;
		this.w=w;
	}
	areaRec()
	{
		this.showShape();
		this.areaa= this.l*this.w;
		console.log("Area of Rectangle "+this.areaa);
	}
}

var objRect = new Rectangle(7,9);
objRect.areaRec();

class Square extends Shape
{
	a:number
	
	constructor(a:number)
	{
		super("Square");
		this.a=a;
	}
	areaSquare()
	{
		this.showShape();
		this.areaa= this.a*this.a;
		console.log("Area of Square "+this.areaa);
	}
}
var objSqr = new Square(4);
objSqr.areaSquare();