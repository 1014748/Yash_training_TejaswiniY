class Circle
{
  radius:number;
  circumference:number;
  constructor (circumference:number)
   {
     this.circumference=circumference;
   }
   show()
   {
     console.log("Circumference:-  "+this.circumference);
   }
   radiusCircle()
	{
		this.show();
		this.radius= this.circumference/(2*3.14);
		console.log("Radius of Circle "+this.radius);
	}
}

var obj = new Circle(10);

obj.radiusCircle();
