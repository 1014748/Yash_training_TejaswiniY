package com.yash;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import java.util.Scanner;
import com.yash.dao.EmployeeDAO;
import com.yash.dao.StudentDAO;
import com.yash.model.*;

public class StudDelDemo {
 public static void main(String s[])
 {	  
	 ApplicationContext objAC = new ClassPathXmlApplicationContext("applicationContext.xml");
	 StudentDAO objed = (StudentDAO) objAC.getBean("sdao");
	
	// System.out.println("Total Record Deleted of City:- "+objed.deleteCity(2));
	 
	 System.out.println("Total Record Deleted of Student:- "+objed.deleteStud(1));		 
}
 }