package com.yash;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Date;
import java.util.Scanner;
import com.yash.dao.EmployeeDAO;
import com.yash.dao.StudentDAO;
import com.yash.model.*;

public class StudMain {
 public static void main(String s[])
 {
	 int ch;
	 ApplicationContext objAC = new ClassPathXmlApplicationContext("applicationContext.xml");
	 StudentDAO objes = (StudentDAO) objAC.getBean("sdao");
	 Student objS = new Student();
	 Scanner sc = new Scanner(System.in);
	 
	// int Studid=0;
	 String StudFName="";
	 String StudLName="";
	 String StudFthName="";
	 String StudMName="";
	 String StudCName="";
	 String StudSection="";
	 String StudGender="";  
	 String Address1="";
	 String Address2="";
	 //Date DOB = new Date();
	 String dateB="";
	// Date DOA = new Date(); 
	 String dateA="";

	 int cityid=0;
	 String City="";
	 String PMobNumber="";
	 String PEmail="";
	 while(true)
	 {
		 
			/*
			 * System.out.println("Select want to do more 1 for yes 0 for no");
			 * ch=sc.nextInt(); if(ch==0) { break; }
			 */ 
			/*
			 * System.out.println("Enter Roll Number"); Studid=sc.nextInt();
			 */
		 System.out.println("Enter First Name");
		 StudFName=sc.nextLine();
		 System.out.println("Enter Last Name");
		 StudLName=sc.nextLine();
		 System.out.println("Enter Father Name");
		 StudFthName=sc.nextLine();
		 System.out.println("Enter Mother Name");
		 StudMName=sc.nextLine();
		 System.out.println("Enter Class Name");
		 StudCName=sc.nextLine();
		 System.out.println("Enter Section");
		 StudSection=sc.nextLine();
		 System.out.println("Enter DOB");
		 dateB=sc.nextLine();
		 System.out.println("Enter DOA");
		 dateA=sc.nextLine();
		 System.out.println("Enter Gender");
		 StudGender=sc.nextLine();
		 System.out.println("Enter Address1");
		 Address1=sc.nextLine();
		 System.out.println("Enter Address2");
		 Address2=sc.nextLine();
		 System.out.println("Enter Parent Email");
		 PEmail=sc.nextLine();
		 System.out.println("Enter Parent MobileNo");
		 PMobNumber=sc.nextLine();
		 System.out.println("Enter City");
		 cityid=sc.nextInt();
		 
		 

		// objS.setStudid(Studid);
		 objS.setStudFName(StudFName);
		 objS.setStudLName(StudLName);
		 objS.setStudFthName(StudFthName);
		 objS.setStudMName(StudMName);
		 objS.setStudCName(StudCName);
		 objS.setStudSection(StudSection);
		 objS.setAddress1(Address1);
		 objS.setAddress2(Address2);
		 objS.setDOA(dateA);
		 objS.setDOB(dateB);
		 //objS.setCity(City);
		 objS.setCityid(cityid);
		 objS.setStudGender(StudGender);
		 objS.setPMobNumber(PMobNumber);
		 objS.setPEmail(PEmail);

		
		// System.out.println("Total record saved in City table:- "+objes.saveCity(objS));

		 System.out.println("Total record saved in Student table:- "+objes.saveStudent(objS));
		 System.out.println("want to do more 1 for yes 0 for no");
		 ch=sc.nextInt();
		 sc.nextLine();
		 if(ch==0)
			 break;
	 }
 }
}
