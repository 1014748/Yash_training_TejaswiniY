package com.yash.model;

import java.util.Date;

public class Student {
  int Studid;
  String StudFName;
  String StudLName;
  String StudFthName;
  String StudMName;
  String StudCName;
  String StudSection;
  String StudGender;  
  String Address1;
  String Address2;
  String DOB;
  String DOA; 
  int cityid;
  String city;
  public String getPMobNumber() {
	return PMobNumber;
}

public void setPMobNumber(String pMobNumber) {
	PMobNumber = pMobNumber;
}

String PMobNumber;
  String PEmail;
  public int getStudid() {
	return Studid;
}

public String getCity() {
	return city;
}

public void setCity(String city) {
	this.city = city;
}

public void setStudid(int studid) {
	Studid = studid;
}

public String getStudFName() {
	return StudFName;
}

public void setStudFName(String studFName) {
	StudFName = studFName;
}

public String getStudLName() {
	return StudLName;
}

public void setStudLName(String studLName) {
	StudLName = studLName;
}

public String getStudFthName() {
	return StudFthName;
}

public void setStudFthName(String studFthName) {
	StudFthName = studFthName;
}

public String getStudMName() {
	return StudMName;
}

public void setStudMName(String studMName) {
	StudMName = studMName;
}

public String getStudCName() {
	return StudCName;
}

public void setStudCName(String studCName) {
	StudCName = studCName;
}

public String getStudSection() {
	return StudSection;
}

public void setStudSection(String studSection) {
	StudSection = studSection;
}

public String getStudGender() {
	return StudGender;
}

public void setStudGender(String studGender) {
	StudGender = studGender;
}

public String getAddress1() {
	return Address1;
}

public void setAddress1(String address1) {
	Address1 = address1;
}

public String getAddress2() {
	return Address2;
}

public void setAddress2(String address2) {
	Address2 = address2;
}

public String getDOB() {
	return DOB;
}

public void setDOB(String dOB) {
	DOB = dOB;
}

public String getDOA() {
	return DOA;
}

public void setDOA(String dOA) {
	DOA = dOA;
}

public int getCityid() {
	return cityid;
}

public void setCityid(int cityid) {
	this.cityid = cityid;
}


public String getPEmail() {
	return PEmail;
}

public void setPEmail(String pEmail) {
	PEmail = pEmail;
}
  
  public Student() {
		super();
	}

	public Student(int Studid, String StudFName,String StudLName,String StudFthName,String StudMName,
	  String StudCName,String StudSection,String StudGender,  String Address1,String Address2,
	  String DOB,String DOA, int cityid,String PMobNumber,String PEmail) {
		
		super();
		
		this.Studid = Studid;
		this.StudFName = StudFName;
		this.StudLName = StudLName;
		this.StudFthName = StudFthName;
		this.StudMName = StudMName;
		this.StudCName = StudCName;
		this.StudSection = StudSection;
		this.StudGender = StudGender;
		this.Address1 = Address1;
		this.Address2 = Address2;
		this.DOB = DOB;
		this.DOA = DOA;
		this.PMobNumber = PMobNumber;
		this.PEmail = PEmail;
	}




  
}
