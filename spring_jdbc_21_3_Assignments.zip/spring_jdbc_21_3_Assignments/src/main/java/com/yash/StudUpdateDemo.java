package com.yash;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import java.util.Scanner;
import com.yash.dao.StudentDAO;
import com.yash.model.*;

public class StudUpdateDemo {
 public static void main(String s[])
 {	  
	 ApplicationContext objAC = new ClassPathXmlApplicationContext("applicationContext.xml");
	 StudentDAO objSd = (StudentDAO) objAC.getBean("sdao");
	 Student objS = (Student) new Student();
	 
	
	 objS.setStudCName("Marathi");
	 objS.setCityid(1);
	 objS.setPMobNumber("9702440072");
	 objS.setStudid(1);
	 
	System.out.println("Total Record updated:- "+objSd.updateStud(objS));		 
	 }
 }