package com.yash.dao;

import org.springframework.jdbc.core.JdbcTemplate;
import com.yash.model.*;
public class StudentDAO {
	JdbcTemplate objJDBC;

	public JdbcTemplate getObjJDBC() {
		return objJDBC;
	}

	public void setObjJDBC(JdbcTemplate objJDBC) {
		this.objJDBC = objJDBC;
	}
	public int saveCity(Student objS)
	{
		String query ="insert into City (cityname) values ('"+objS.getCity()+"')";
				int no;
				no = objJDBC.update(query);
				return no;
	}
	public int saveStudent(Student objS)
	{
		String query ="insert into Student (StudFName,StudLName,StudFthName,StudMName,StudCName,StudSection,StudGender,DOA,DOB,Address1,Address2,PMobNumber,PEmail,Cityid) values ('"+objS.getStudFName()+"','"+objS.getStudLName()+"','"+objS.getStudFthName()+"','"+objS.getStudMName()+"','"+objS.getStudCName()+
				"','"+objS.getStudSection()+"','"+objS.getDOB()+"','"+objS.getDOA()+"','"+objS.getStudGender()+
				"','"+objS.getAddress1()+"','"+objS.getAddress2()+"','"+objS.getPMobNumber()+"','"+objS.getPEmail()+"',"+objS.getCityid()+")";
				int no;
				no = objJDBC.update(query);
				return no;
	}
	public int updateStud(Student objS)
	{
		/*
		 * String
		 * query="update Student set StudFName='"+objS.getStudFName()+"' ,StudLName='"
		 * +objS.getStudLName()+"'"
		 * +" ,StudFthName='"+objS.getStudFthName()+"' ,StudMName='"+objS.getStudMName()
		 * +"' ,StudCName='"+objS.getStudCName()+"' ,StudSection='"+objS.getStudFName()+
		 * "'" +" ,StudGender='"+objS.getStudGender()+"' ,DOA='"+objS.getDOA()+"'"
		 * +" ,DOB='"+objS.getDOB()+"' ,Address1='"+objS.getAddress1()+"'"
		 * +" ,Address2='"+objS.getAddress2()//+"' ,cityid='"+objS.getCityid()+"' ,"
		 * +" ,PMobNumber='"+objS.getPMobNumber()+"' ,PEmail='"+objS.getPEmail()+"'"
		 * +" where StudRoll="+objS.getStudid();
		 */
		
		String query="update Student set StudCName='"+objS.getStudCName()+"' ,Cityid="+objS.getCityid()
				+" ,PMobNumber='"+objS.getPMobNumber()+"'"
				+" where StudRoll="+objS.getStudid();
		
		int no;
		no =objJDBC.update(query);
		return no;
			
	}
	public int deleteCity(int cityid)
	{
		String query ="delete from city where cityid="+cityid;
		return objJDBC.update(query);
	}
	public int deleteStud(int StudRoll)
	{
		String query ="delete from Student where StudRoll="+StudRoll;
		return objJDBC.update(query);
	}
	
}
